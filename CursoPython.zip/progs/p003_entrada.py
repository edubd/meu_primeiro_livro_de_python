# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 12:09:04 2018

@author: notebook
"""

#P003: Entrada de dados
nome = input("Qual o seu nome?\n")
print("Hmmm... então você é o famoso " + nome)

