# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 10:46:00 2019

@author: notebook
"""

#P024: repetição e concatenação de listas 
lst1 = ['Niterói','RJ']
lst2 = ['Brasil']

#repetição: operador *
print(lst1*3) #['Niterói','RJ','Niterói','RJ','Niterói','RJ'] 

#concatenação: operador +
print(lst1 + lst2) #['Niterói','RJ','Brasil'] 

