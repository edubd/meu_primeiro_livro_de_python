# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 18:40:49 2020

@author: eduar
"""

#P116: Modificando Atributos
class Musica:

    #construtor: inicializa as propriedades
    def __init__(self, p_nome, p_artista, p_estilos):
        self.nome = p_nome
        self.artista = p_artista
        self.estilos = p_estilos

    #método tocar()
    def tocar(self):
        return "tocando '{}' por {}...".format(self.nome, self.artista)

#cria um objeto e imprime seus atributos
m3 = Musica("O Mundo é um Moinho","Cartola",["Samba"]);

print("* dados originais:")
print("musica: ", m3.nome);
print("artista: ", m3.artista);
print("gênero: ", m3.estilos);

#modifica o valor do atributo “estilos”
m3.estilos = ["MPB", "Samba"]
print("\n* dados após modificação:")
print("musica: ", m3.nome);
print("artista: ", m3.artista);
print("gêneros: ", m3.estilos);

