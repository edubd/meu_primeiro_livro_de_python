# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 09:09:23 2020

@author: eduar
"""

#fatiamento e indexação de matrizes
import numpy as np 

m = np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12]])

#1-fatiamento e indexação estilo lista
print('m[1,2]=',m[1,2])
print('m[-1,-2]=',m[-1,-2])
print('m[2]=',m[2])
print('m[:,:3]=',m[:,:3])
print('m[:,-2:]=',m[:,-2:])
print('m[:2,1:3]=',m[:2,1:3])
print('--------------------')

#2-fatiamento estilo range()
print('m[0:3:2,0:4:2]=',m[0:3:2,0:4:2])
print('m[:,1::2]=',m[:,1::2])
print('--------------------')

#3-fancy indexing
print('m[[2,0]]=',m[[2,0]])
print('m[[2,0],[1,3]]=',m[[2,0],[1,3]])
print('m[[2,0]][:,[1,3]]=',m[[2,0]][:,[1,3]])
