# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 19:34:27 2020

@author: eduar
"""

#P117: Atributos de Classe x Atributos de Instância
class Marciano:

    #atributo de classe – todo marciano é verde...
    cor = 'verde'

    #construtor: inicializa os atributos de instância
    def __init__(self, p_nome, p_tipo):
        self.nome = p_nome
        self.tipo = p_tipo

    #método get_info(): recupera o nome e a cor do Marciano
    def get_info(self):
        return "Me chamo {} e sou {}".format(self.nome, self.cor)

    #método get_mensagem(): retorna a frase que o Marciano dirá ao primeiro
    #                       ser humano que ele encontrar pela frente
    def get_mensagem(self, nome_ser_humano):
        if self.tipo.lower() == 'bom':
            return "{}, eu vim em missão de paz!".format(nome_ser_humano)
        else:
            return "{}, vou te abduzir e escravizar!".format(nome_ser_humano)

#cria dois marcianos, um bom e um mau
marciano_bom = Marciano("Tarkas","bom");
marciano_mau = Marciano("Manhunter","mau");

#o marciano bom encontrou a Anita
print(marciano_bom.get_info())
print(marciano_bom.get_mensagem("Ludmilla"))

#o marciano mau encontrou a Rihanna
print('----------------------------')
print(marciano_mau.get_info())
print(marciano_mau.get_mensagem("Rihanna"))
