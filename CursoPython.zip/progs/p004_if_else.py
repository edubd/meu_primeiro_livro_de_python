# -*- coding: utf-8 -*-
"""
Created on Sat Jan  5 13:40:25 2019

@author: notebook
"""

#P004: desvio condicional com if: e else:
idade = 17
if (idade >= 18) :
    print("Pode entrar, a festa está bombando!")
    print("Temos muita música e drinks especiais!!!")
else :
    print("Você é jovem demais para este clube! Volte apenas quando fizer 18.")
