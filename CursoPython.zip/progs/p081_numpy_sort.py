# -*- coding: utf-8 -*-
"""
Created on Wed Feb  6 19:37:32 2019

@author: ecorrea
"""

 #P081: percorrendo as células de uma matriz 
import numpy as np  
vet_paises = np.array(['Uruguai', 'Brasil', 
                       'Chile', 'Costa Rica', 'Equador']) 
vet_paises.sort()
print(vet_paises) 