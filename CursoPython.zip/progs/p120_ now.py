# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 21:52:03 2020

@author: eduar
"""

#P120: Recuperando a data/hora do sistema
import datetime

agora = datetime.datetime.now()
print("tipo da variável:",type(agora))
print("data/hora corrente:", agora)
