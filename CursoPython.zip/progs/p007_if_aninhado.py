# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 14:56:38 2019

@author: notebook
"""

#P007: instruções condicionais aninhadas
a=5; b=10
if (a == b):  
    print("a e b são iguais")
else: 
    if (a > b):
        print("a é maior do que b")
    else:
        print("a é menor do que b")

