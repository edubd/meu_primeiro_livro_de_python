# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 21:59:03 2020

@author: eduar
"""

#P036: **kwargs
def pessoa(**kwargs):
    for chave, valor in kwargs.items():
        print("{0} = {1}".format(chave,valor))

#Sintaxe 1: nome=valor
pessoa(nome='John', profissao='musico')
print("\n")

#Sintaxe 2: passando explicitamente um dicionário (**dicionario)
d={'nome':'Jane','profissao':'escritora','signo':'sagitário'}
pessoa(**d)
print("\n")