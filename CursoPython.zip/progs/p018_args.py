# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 21:45:54 2020

@author: eduar
"""

#P018: *args
def pessoa(nome, *args):
    print("- nome (primeiro parâmetro): ", nome)
    print("- características (outros parâmetros): ")
    for arg in args:
        print("\t",arg)

pessoa('Jane','escritora','sagitariana','romântica')
print("\n")
pessoa('John','músico')