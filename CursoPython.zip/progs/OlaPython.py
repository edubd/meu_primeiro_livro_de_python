# -*- coding: utf-8 -*-
"""
Created on Sun Feb  2 19:19:03 2020

@author: eduar
"""

print('Olá Python!')