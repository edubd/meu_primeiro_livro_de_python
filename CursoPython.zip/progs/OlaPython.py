# -*- coding: utf-8 -*-
"""
Created on Thu Jan  3 21:39:30 2019

@author: notebook
"""

print('Olá Python!')

