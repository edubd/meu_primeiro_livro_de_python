# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 11:53:19 2019

@author: notebook
"""

#P016: função que não retorna valor
def imprime_cabecalho(nome):
    print("\n---------------------------------------")
    print("* * Relatório - " + nome)
    print("---------------------------------------\n")

imprime_cabecalho('Produtos Mais Vendidos')
imprime_cabecalho('Produtos Esgotados')
