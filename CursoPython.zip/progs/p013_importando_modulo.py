# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 11:43:30 2019

@author: notebook
"""

#P013: importando e utilizando uma função de um módulo
import minhas_funcoes

a = minhas_funcoes.faixa_etaria(15)
b = minhas_funcoes.faixa_etaria(50)
c = minhas_funcoes.faixa_etaria(35)

print(a); print(b); print(c)	
