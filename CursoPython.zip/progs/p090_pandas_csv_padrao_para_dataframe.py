# -*- coding: utf-8 -*-
"""
Created on Sat Feb  9 13:47:05 2019

@author: notebook
"""

#P090: Importação de CSV padrão para DataFrame
import pandas as pd  
pessoas = pd.read_csv('C:/CursoPython/pessoas.csv')
print(pessoas)           
