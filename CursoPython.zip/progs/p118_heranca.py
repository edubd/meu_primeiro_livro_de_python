# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 20:48:41 2020

@author: eduar
"""

#P118: Herança

#Classe pai
class Animal:

    #atributo de classe
    tipo = "Animal"

    #construtor: inicializa os atributos de instância
    def __init__(self, p_nome):
        self.nome = p_nome

    #método get_nome(): recupera o nome do animal
    def get_nome(self):
        return self.nome


#Classe filha – Cachorro
class Cachorro(Animal):

    #sobrescreve o atributo de classe
    tipo = "cão"

    #método conversar: como o animal conversa 
    def conversar(self):
        return "au au au!"

#Classe filha – Gato
class Gato(Animal):

    #sobrescreve o atributo de classe
    tipo = "gato"

    #método conversar: como o animal conversa 
    def conversar(self):
        return "miau miau miau!"


#cria três animais, dois gatos e um cachorro
nanquim = Gato("Nanquim");
pacato = Gato("Pacato");
dinamite = Cachorro("Dinamite");

#interação com os animais
print("{} é um {}".format(nanquim.get_nome(), nanquim.tipo))
print(nanquim.conversar())
print('----------------------------')
print("{} é um {}".format(pacato.get_nome(), pacato.tipo))
print(pacato.conversar())
print('----------------------------')
print("{} é um {}".format(dinamite.get_nome(), dinamite.tipo))
print(dinamite.conversar())
