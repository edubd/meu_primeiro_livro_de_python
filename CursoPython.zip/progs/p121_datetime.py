# -*- coding: utf-8 -*-
"""
Created on Sat Feb 22 12:00:56 2020

@author: eduar
"""

#P121: Operações básicas sobre datetimes
import datetime

#1.1-Podemos criar datetimes com o método datetime()...
d0 = datetime.datetime(2020,2,22,12,5,48)

#1.2-E também com strptime(), passando uma timestring + máscara de formatação
str1='2020-02-22'
str2='2020-02-22 12:05:48'

d1 = datetime.datetime.strptime(str1,"%Y-%m-%d") 
d2 = datetime.datetime.strptime(str2,"%Y-%m-%d %H:%M:%S") 

d3 = d2 + datetime.timedelta(365) #soma 365 dias à d2

#2-Imprime os datetimes
print(d0)   #2020-02-22 12:05:48
print(d1)   #2020-02-22 00:00:00
print(d2)   #2020-02-22 12:05:48
print(d3)   #2020-03-03 12:05:48



