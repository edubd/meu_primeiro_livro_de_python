﻿# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 10:57:17 2019

@author: notebook
"""

#P026: aplicando funções pré-definidas sobre listas
lst_qi = [126, 100, 130, 92, 120, 99, 125, 72]

print("resultados do teste de QI: ", lst_qi)
print("maior: ", max(lst_qi))
print("menor: ", min(lst_qi))
print("soma: ", sum(lst_qi))
print("media: ", sum(lst_qi) / len(lst_qi))

