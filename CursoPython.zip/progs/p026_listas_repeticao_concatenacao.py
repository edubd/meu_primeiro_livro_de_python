# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 10:46:00 2019

@author: notebook
"""

#P026: repetição e concatenação de listas 
lst1 = ['UFF','Niterói','RJ']
lst2 = ['Brasil']

#repetição: operador *
print(lst1*3) #['UFF','Niterói','RJ','UFF','Niterói','RJ','UFF','Niterói','RJ'] 

#concatenação: operador +
print(lst1 + lst2) #['UFF','Niterói','RJ','Brasil'] 

