# -*- coding: utf-8 -*-
"""
Created on Sat Feb 22 16:14:10 2020

@author: eduar
"""

#P123: método strftime
import datetime

#1-pega a datetime do sistema
d = datetime.datetime.now()

#2-extrai partes com strftime
print("data/hora completa = ",d)
print("dia/mês/ano = ", d.strftime("%d/%m/%Y"))
print("hora:minuto:segundo = ", d.strftime("%H:%M:%S"))
print("só a hora = ", d.strftime("%H"))
print("só o ano com 2 dígitos = ", d.strftime("%y"))
print("só o nome abreviado do mês = ", d.strftime("%b"))

