# -*- coding: utf-8 -*-
"""
Created on Sat Feb 22 16:00:23 2020

@author: eduar
"""

#P122: trabalhando com a classe time
import datetime

t1=datetime.time(12,5,48)

print("tipo da variável:",type(t1))
print("valor de t1:", t1)            #12:05:48