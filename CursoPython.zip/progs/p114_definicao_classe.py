# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 16:00:46 2020

@author: eduar
"""

#P114: Definição de classe + método __init__()
class Musica:

    #construtor: inicializa as propriedades
    def __init__(self, p_nome, p_artista, p_estilos):
        self.nome = p_nome
        self.artista = p_artista
        self.estilos = p_estilos

    #método tocar()
    def tocar(self):
        return "tocando '{}' por {}...".format(self.nome, self.artista)
