# -*- coding: utf-8 -*-
"""
Created on Sat Feb 22 17:22:14 2020

@author: eduar
"""

#P124: trabalhando com a classe timedelta
import datetime

#1-Cria os timedeltas
semana=datetime.timedelta(weeks=1)  #7 dias
ano=datetime.timedelta(365)         #365 dias
dia_e_meio=datetime.timedelta(days=1, hours=12) #1,5 dias

#2-imprime-os
print("semana=", semana)          #7 days, 0:00:00
print("ano=", ano)                #365 days, 0:00:00
print("dia_e_meio=", dia_e_meio)  #1 day, 12:00:00

#3-soma cada timedelta ao datetime 01/01/2020 20:00:00 
d = datetime.datetime(2020,1,1,20,0,0)
print('---------------------')  
print("d=", d)                             #2020-01-01 20:00:00
print("d + semana=", d + semana)           #2020-01-08 20:00:00
print("d + ano =", d + ano)                #2020-12-31 20:00:00
print("d + dia_e_meio =", d + dia_e_meio)  #2020-01-03 08:00:00