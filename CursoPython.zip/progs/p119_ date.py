# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 21:52:03 2020

@author: eduar
"""

#P119: Operações básicas sobre datas (date)
import datetime

#1-Cria uma data com o método date(). Basta passar ano, mes, dia
natal = datetime.date(2020,12,25) 

#2-imprime a data e partes da mesma
print('tipo da variável:', type(natal)) #<class 'datetime.date'>
print('natal (data completa)=', natal)  #2020-12-25
print('natal - dia=', natal.day)        #25
print('natal - mês=', natal.month)      #12
print('natal - ano=', natal.year)       #2020
print('---------------------')  

#Qual o dia da semana?
#0-Monday; 1-Tuesday; 2-Wednesday; 3-Thursday; 4-Friday; 5-Saturday; 6-Sunday
print('natal - dia da semana=', natal.weekday()) #4 

#3-Soma e subtrai dias
dias = datetime.timedelta(10) #10 dias 
d1 = natal - dias #resulta em 2020-15-12 
d2 = natal + dias #resulta em 2021-04-01 
x = d2 - d1       #resulta em 20 (diferença em dias entre as duas datas)

print('---------------------')  
print('10 dias antes do natal=', d1)   #2020-15-12
print('10 dias depois do natal=', d2)  #2021-04-01
print('---------------------')  
print('x=d2-21=', x)  #20 days, 0:00:00
print('type(x)=', type(x))  

#4-Comparando datas. Basta utilizar os operadores relacionais normalmente
print('---------------------')  
print(d1 < d2)   #True
print(d1 == d2)  #False
print(d1 > d2)   #False
