# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 22:31:54 2020

@author: eduar
"""

#P020: função lambda
soma = lambda x,y: x + y
print(soma(1,2))	#3
print(soma(5,10)) #15
