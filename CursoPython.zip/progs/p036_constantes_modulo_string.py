# -*- coding: utf-8 -*-
"""
Created on Sat Jan 26 12:54:29 2019

@author: notebook
"""

#P036: constantes do módulo string
import string
print(string.ascii_lowercase)   #abcdefghijklmnopqrstuvwxyz
print(string.ascii_uppercase)   #ABCDEFGHIJKLMNOPQRSTUVWXYZ
print(string.ascii_letters)     #abcdefghijklmnopqrstuvwxyzABCDEFGHIJK
                                #LMNOPQRSTUVWXYZ

print(string.digits)            #0123456789
print(string.punctuation)       #!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~