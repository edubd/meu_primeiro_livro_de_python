# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 16:54:55 2020

@author: eduar
"""

#P115: Instanciando Objetos
class Musica:

    #construtor: inicializa as propriedades
    def __init__(self, p_nome, p_artista, p_estilos):
        self.nome = p_nome
        self.artista = p_artista
        self.estilos = p_estilos

    #método tocar()
    def tocar(self):
        return "tocando '{}' por {}...".format(self.nome, self.artista)

#instancia um objeto do tipo Musica
m1 = Musica("Wave","Tom Jobim",["Bossa Nova","Jazz"]);

#instancia outro objeto do tipo Musica
m2 = Musica("You Know I’m No Good","Amy Winehouse",["Jazz","Pop","Soul"]);

#chama o método tocar() para cada objeto
print('* música 1: ');
print(m1.tocar())

print('\n* Agora a música 2: ');
print(m2.tocar())
